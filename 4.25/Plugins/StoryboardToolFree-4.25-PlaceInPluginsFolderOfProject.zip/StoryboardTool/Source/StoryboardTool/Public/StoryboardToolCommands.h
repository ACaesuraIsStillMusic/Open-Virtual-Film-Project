// Copyright Epic Games, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Framework/Commands/Commands.h"
#include "StoryboardToolStyle.h"

class FStoryboardToolCommands : public TCommands<FStoryboardToolCommands>
{
public:

	FStoryboardToolCommands()
		: TCommands<FStoryboardToolCommands>(TEXT("StoryboardTool"), NSLOCTEXT("Contexts", "StoryboardTool", "StoryboardTool Plugin"), NAME_None, FStoryboardToolStyle::GetStyleSetName())
	{
	}

	// TCommands<> interface
	virtual void RegisterCommands() override;

public:
	TSharedPtr< FUICommandInfo > PluginAction;
};
