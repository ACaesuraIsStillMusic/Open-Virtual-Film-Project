// Copyright Dan Corrigan 2020 All Rights Reserved.

#include "StoryboardToolBPLibrary.h"
#include "StoryboardTool.h"
#include "StoryboardToolSettings.h"
#include "HighResScreenshot.h"
#include "LevelEditor.h"
#include "SLevelViewport.h"
#include "Engine/GameEngine.h"

#include "Engine/TextureRenderTarget2D.h"

UStoryboardToolBPLibrary::UStoryboardToolBPLibrary(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{

}

#if WITH_EDITOR
bool UStoryboardToolBPLibrary::VPStoryboardToolGetActorLockedState(AActor* actor) //Get locked state
{


	return actor->bLockLocation;
}


bool UStoryboardToolBPLibrary::VPStoryboardToolSetActorLockedState(AActor* actor, bool newState) //Set locked state
{
	actor->bLockLocation = newState;
	return actor->bLockLocation;
}


void UStoryboardToolBPLibrary::VPStoryboardToolSetRenderTargetMode(UTextureRenderTarget2D* renderTarget, TEnumAsByte < ETextureRenderTargetFormat > RenderFormat)
{
	renderTarget->RenderTargetFormat = RenderFormat;

	return;
}

void UStoryboardToolBPLibrary::VPStoryboardToolSetRenderTargetSize(UTextureRenderTarget2D* renderTarget, int sizeX, int sizeY)
{
	renderTarget->SizeX = sizeX;
	renderTarget->SizeY = sizeY;

	return;
}

FSoftObjectPath UStoryboardToolBPLibrary::VPStoryboardToolGetDefaultCameraClass() //get default camera class
{

	FSoftObjectPath camera = GetDefault<UStoryboardToolSettings>()->DefaultCamera;
	return camera;
	//return nullptr;
}

FText UStoryboardToolBPLibrary::VPStoryboardToolGetScreenshotFormat() //get default camera class
{

	FText format = GetDefault<UStoryboardToolSettings>()->ScreenshotFormat;
	return format;

}

FString UStoryboardToolBPLibrary::VPStoryboardToolGetArtistInitials() //get default camera class
{

	FString initials = GetDefault<UStoryboardToolSettings>()->ArtistInitials;
	return initials;

}

int UStoryboardToolBPLibrary::VPStoryboardToolGetScreenshotxSize() //get default camera class
{

	int sizeX = GetDefault<UStoryboardToolSettings>()->ScreenshotxSize;
	return sizeX;

}



bool UStoryboardToolBPLibrary::VPStoryboardToolTakeAdvancedScreenshot(FString Filename, int sizeX, int sizeY)
{

#if WITH_EDITOR
	if (FModuleManager::Get().IsModuleLoaded("LevelEditor"))
	{
		FHighResScreenshotConfig& HighResScreenshotConfig = GetHighResScreenshotConfig();
		if (HighResScreenshotConfig.SetResolution(sizeX, sizeY))//ResX, ResY))
		{
			HighResScreenshotConfig.SetResolution(sizeX, sizeY);
			HighResScreenshotConfig.SetFilename(Filename);
			//HighResScreenshotConfig.SetMaskEnabled(bMaskEnabled);
			//HighResScreenshotConfig.SetHDRCapture(bCaptureHDR);

			FLevelEditorModule& LevelEditor = FModuleManager::GetModuleChecked<FLevelEditorModule>("LevelEditor");
			SLevelViewport* LevelViewport = LevelEditor.GetFirstActiveLevelViewport().Get();

			//finish loading the levels before taking the screenshot

			FlushAsyncLoading();

			// Make sure we finish all level streaming
			if (UGameEngine* GameEngine = Cast<UGameEngine>(GEngine))
			{
				if (UWorld* GameWorld = GameEngine->GetGameWorld())
				{
					GameWorld->FlushLevelStreaming(EFlushLevelStreamingType::Full);
				}
			}

			// Force all mip maps to load before taking the screenshot. Results in a higher quality image
			UTexture::ForceUpdateTextureStreaming();

			IStreamingManager::Get().StreamAllResources(0.0f);





			return LevelViewport->GetActiveViewport()->TakeHighResScreenShot();

			//reset the high res screenshot system
			//HighResScreenshotConfig.SetResolution(0, 0);
			//HighResScreenshotConfig.SetFilename("");
		}



	}
#endif	
	return false;
}

void UStoryboardToolBPLibrary::VPStoryboardToolResetScreenshotParameters()
{
	if (FModuleManager::Get().IsModuleLoaded("LevelEditor"))
	{
		FHighResScreenshotConfig& HighResScreenshotConfig = GetHighResScreenshotConfig();

		HighResScreenshotConfig.SetResolution(0, 0);
		HighResScreenshotConfig.SetFilename("");


	}


}


#endif
