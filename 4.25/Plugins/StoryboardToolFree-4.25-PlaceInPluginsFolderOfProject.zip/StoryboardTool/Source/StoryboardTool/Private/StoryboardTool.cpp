// Copyright Dan Corrigan 2020 All Rights Reserved.

#include "StoryboardTool.h"
#include "StoryboardToolStyle.h"
#include "StoryboardToolCommands.h"
#include "ToolMenus.h"
#include "EditorUtilitySubsystem.h"

static const FName StoryboardToolTabName("StoryboardTool");

#define LOCTEXT_NAMESPACE "FStoryboardToolModule"

void FStoryboardToolModule::StartupModule()
{
	// This code will execute after your module is loaded into memory; the exact timing is specified in the .uplugin file per-module
	
	FStoryboardToolStyle::Initialize();
	FStoryboardToolStyle::ReloadTextures();

	FStoryboardToolCommands::Register();
	
	PluginCommands = MakeShareable(new FUICommandList);

	PluginCommands->MapAction(
		FStoryboardToolCommands::Get().PluginAction,
		FExecuteAction::CreateRaw(this, &FStoryboardToolModule::PluginButtonClicked),
		FCanExecuteAction());

	UToolMenus::RegisterStartupCallback(FSimpleMulticastDelegate::FDelegate::CreateRaw(this, &FStoryboardToolModule::RegisterMenus));
}

void FStoryboardToolModule::ShutdownModule()
{
	// This function may be called during shutdown to clean up your module.  For modules that support dynamic reloading,
	// we call this function before unloading the module.

	UToolMenus::UnRegisterStartupCallback(this);

	UToolMenus::UnregisterOwner(this);

	FStoryboardToolStyle::Shutdown();

	FStoryboardToolCommands::Unregister();
}

void FStoryboardToolModule::PluginButtonClicked()
{
	// Put your "OnButtonClicked" stuff here
	//On main button clicked, open the widget blueprint splash page
	
	UObject* Obj = LoadObject<UObject>(nullptr, TEXT("/StoryboardTool/StoryboardingTool/VP_StoryboardTool.VP_StoryboardTool"), NULL, LOAD_None, NULL);
	UEditorUtilityWidgetBlueprint* WidgetBP = (UEditorUtilityWidgetBlueprint*)Obj;
	FStoryboardToolModule::RunWidget(WidgetBP); //Open the blutility
}

void FStoryboardToolModule::RunWidget(UEditorUtilityWidgetBlueprint* Blueprint)
{
	if (Blueprint) {
		UEditorUtilitySubsystem* EditorUtilitySubsystem = GEditor->GetEditorSubsystem<UEditorUtilitySubsystem>();
		EditorUtilitySubsystem->SpawnAndRegisterTab(Blueprint);

	}
}


void FStoryboardToolModule::RegisterMenus()
{
	// Owner will be used for cleanup in call to UToolMenus::UnregisterOwner
	FToolMenuOwnerScoped OwnerScoped(this);

	{
		UToolMenu* Menu = UToolMenus::Get()->ExtendMenu("LevelEditor.MainMenu.Window");
		{
			FToolMenuSection& Section = Menu->FindOrAddSection("WindowLayout");
			Section.AddMenuEntryWithCommandList(FStoryboardToolCommands::Get().PluginAction, PluginCommands);
		}
	}

	{
		UToolMenu* ToolbarMenu = UToolMenus::Get()->ExtendMenu("LevelEditor.LevelEditorToolBar");
		{
			FToolMenuSection& Section = ToolbarMenu->FindOrAddSection("Storyboard");
			{
				FToolMenuEntry& Entry = Section.AddEntry(FToolMenuEntry::InitToolBarButton(FStoryboardToolCommands::Get().PluginAction));
				Entry.SetCommandList(PluginCommands);
			}
		}
	}
}

#undef LOCTEXT_NAMESPACE
	
IMPLEMENT_MODULE(FStoryboardToolModule, StoryboardTool)