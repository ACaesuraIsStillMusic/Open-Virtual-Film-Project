// Copyright Dan Corrigan 2020 All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Engine/EngineTypes.h"
#include "Engine/DeveloperSettings.h"

#include "StoryboardToolSettings.generated.h"

/**
 * Configure the Python plug-in.
 */
UCLASS(config = Engine, defaultconfig)
class UStoryboardToolSettings : public UDeveloperSettings
{
	GENERATED_BODY()

public:
	UStoryboardToolSettings();

#if WITH_EDITOR

	//~ UDeveloperSettings interface
	virtual FText GetSectionText() const override;
#endif
	/*
	UPROPERTY(config, EditAnywhere, Category = Python, meta = (ConfigRestartRequired = true, MultiLine = true))
		TArray<FString> StartupScripts;

	UPROPERTY(config, EditAnywhere, Category = Python, meta = (ConfigRestartRequired = true, RelativePath))
		TArray<FDirectoryPath> AdditionalPaths;

	UPROPERTY(config, EditAnywhere, Category = Python, meta = (ConfigRestartRequired = true))
		bool bDeveloperMode;

	UPROPERTY(config, EditAnywhere, Category = PythonRemoteExecution, meta = (DisplayName = "Enable Remote Execution?"))
		bool bRemoteExecution;
	*/
	/** The multicast group endpoint (in the form of IP_ADDRESS:PORT_NUMBER) that the UDP multicast socket should join */

	// AllowedClasses = "CineCamera"
	UPROPERTY(config, EditAnywhere, Category = Setup, meta = (DisplayName = "Default Camera Class"))
		FSoftObjectPath DefaultCamera;

	UPROPERTY(config, EditAnywhere, Category = ScreenshotSetup, meta = (DisplayName = "Screenshot Format"))
		FText ScreenshotFormat = FText::FromString("{setNumber}_{setName}_{date}_{cameraName}{cameraMode}_{version}_{initials}-{millisecond}");

	UPROPERTY(config, EditAnywhere, Category = ScreenshotSetup, meta = (DisplayName = "Artist Initials"))
		FString ArtistInitials = "FC";

	UPROPERTY(config, EditAnywhere, Category = ScreenshotSetup, meta = (DisplayName = "Screenshot width"))
		int ScreenshotxSize = 4096;
};
