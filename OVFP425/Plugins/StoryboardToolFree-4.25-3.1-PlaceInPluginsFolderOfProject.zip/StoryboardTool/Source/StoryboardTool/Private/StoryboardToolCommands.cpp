// Copyright Epic Games, Inc. All Rights Reserved.

#include "StoryboardToolCommands.h"

#define LOCTEXT_NAMESPACE "FStoryboardToolModule"

void FStoryboardToolCommands::RegisterCommands()
{
	UI_COMMAND(PluginAction, "StoryboardTool", "Execute StoryboardTool action", EUserInterfaceActionType::Button, FInputGesture());
}

#undef LOCTEXT_NAMESPACE
