// Copyright Dan Corrigan 2020 All Rights Reserved.

#include "StoryboardToolCommands.h"

#define LOCTEXT_NAMESPACE "FStoryboardToolModule"

void FStoryboardToolCommands::RegisterCommands()
{
	UI_COMMAND(PluginAction, "Storyboard Tool", "Open Storyboard Tool", EUserInterfaceActionType::Button, FInputGesture());
}

#undef LOCTEXT_NAMESPACE
