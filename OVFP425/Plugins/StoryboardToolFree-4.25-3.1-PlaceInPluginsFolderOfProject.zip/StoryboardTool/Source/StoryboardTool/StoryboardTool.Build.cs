// Copyright Dan Corrigan 2020 All Rights Reserved.

using UnrealBuildTool;

public class StoryboardTool : ModuleRules
{
	public StoryboardTool(ReadOnlyTargetRules Target) : base(Target)
	{
        PCHUsage = ModuleRules.PCHUsageMode.UseExplicitOrSharedPCHs;


        PublicDependencyModuleNames.AddRange(new string[] {
            "EditorSubsystem",
            "MainFrame",
            "Core",
            "AssetRegistry",
            "UnrealEd",
        });

       
		
		PrivateDependencyModuleNames.AddRange(
			new string[]
			{
				"Projects",
				"InputCore",
				"ToolMenus",
				"CoreUObject",
				"Engine",
				"Slate",
				"SlateCore",
				// ... add private dependencies that you statically link with here ...	
                "LevelEditor",
                "Blutility",
                "UMG",
                "UMGEditor",
            }
			);
		
		
		DynamicallyLoadedModuleNames.AddRange(
			new string[]
			{
				// ... add any modules that your module loads dynamically here ...
			}
			);
	}
}
