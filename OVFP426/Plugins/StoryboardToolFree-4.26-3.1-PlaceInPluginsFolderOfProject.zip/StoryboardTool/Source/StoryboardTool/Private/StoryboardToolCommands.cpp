// Copyright Epic Games, Inc. All Rights Reserved.

#include "StoryboardToolCommands.h"

#define LOCTEXT_NAMESPACE "FStoryboardToolModule"

void FStoryboardToolCommands::RegisterCommands()
{
	UI_COMMAND(PluginAction, "Storyboard Tool", "Open Storyboard Tool", EUserInterfaceActionType::Button, FInputGesture());
}

#undef LOCTEXT_NAMESPACE
