// Copyright Dan Corrigan 2020 All Rights Reserved.

#pragma once

#include "Kismet/BlueprintFunctionLibrary.h"
#include "Engine/TextureRenderTarget2D.h"
#include "StoryboardToolBPLibrary.generated.h"



UCLASS()
class UStoryboardToolBPLibrary : public UBlueprintFunctionLibrary
{
	GENERATED_UCLASS_BODY()

#if WITH_EDITOR
		UFUNCTION(BlueprintCallable, meta = (DisplayName = "Get Actor Locked State", Keywords = "VPStoryboardTools Virtual Production VP"), Category = "VPStoryboardTools")
		static bool VPStoryboardToolGetActorLockedState(AActor *actor);

	UFUNCTION(BlueprintCallable, meta = (DisplayName = "Set Actor Locked State", Keywords = "VPStoryboardTools Virtual Production VP"), Category = "VPStoryboardTools")
		static bool VPStoryboardToolSetActorLockedState(AActor *actor, bool newState);

	UFUNCTION(BlueprintCallable, meta = (DisplayName = "Set Render Target Format", Keywords = "VPStoryboardTools Virtual Production VP"), Category = "VPStoryboardTools")
		static void VPStoryboardToolSetRenderTargetMode(UTextureRenderTarget2D *renderTarget, TEnumAsByte < ETextureRenderTargetFormat > format);
	UFUNCTION(BlueprintCallable, meta = (DisplayName = "Set Render Target Size", Keywords = "VPStoryboardTools Virtual Production VP"), Category = "VPStoryboardTools")
		static void VPStoryboardToolSetRenderTargetSize(UTextureRenderTarget2D *renderTarget, int sizeX, int sizeY);
	UFUNCTION(BlueprintCallable, meta = (DisplayName = "Get Default Camera Class", Keywords = "VPStoryboardTools Virtual Production VP"), Category = "VPStoryboardTools")
		static FSoftObjectPath VPStoryboardToolGetDefaultCameraClass();

	UFUNCTION(BlueprintCallable, meta = (DisplayName = "Get Screenshot Name Format", Keywords = "VPStoryboardTools Virtual Production VP"), Category = "VPStoryboardTools")
		static FText VPStoryboardToolGetScreenshotFormat();

	UFUNCTION(BlueprintPure, meta = (DisplayName = "Get Artist Initials", Keywords = "VPStoryboardTools Virtual Production VP"), Category = "VPStoryboardTools")
		static FString VPStoryboardToolGetArtistInitials();

	UFUNCTION(BlueprintPure, meta = (DisplayName = "Get Screenshot Default X Size", Keywords = "VPStoryboardTools Virtual Production VP"), Category = "VPStoryboardTools")
		static int VPStoryboardToolGetScreenshotxSize();





	UFUNCTION(BlueprintCallable, meta = (DisplayName = "Take Advanced Screenshot", Keywords = "VPStoryboardTools Virtual Production VP"), Category = "VPStoryboardTools")
		static bool VPStoryboardToolTakeAdvancedScreenshot(FString Filename = "", int sizeX = 0, int sizeY = 0);
	UFUNCTION(BlueprintCallable, meta = (DisplayName = "Reset Screenshot Parameters", Keywords = "VPStoryboardTools Virtual Production VP"), Category = "VPStoryboardTools")
		static void VPStoryboardToolResetScreenshotParameters();
#endif	
};
