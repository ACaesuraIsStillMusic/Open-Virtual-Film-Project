// Copyright Dan Corrigan 2020 All Rights Reserved.

#include "StoryboardToolSettings.h"
#include "StoryboardTool.h"

#define LOCTEXT_NAMESPACE "StoryboardTool"

UStoryboardToolSettings::UStoryboardToolSettings()
{
	CategoryName = TEXT("Plugins");
	SectionName = TEXT("StoryboardTool");


	DefaultCamera;
}

#if WITH_EDITOR




FText UStoryboardToolSettings::GetSectionText() const
{
	return LOCTEXT("SettingsDisplayName", "StoryboardTool");
}

#endif	// WITH_EDITOR

#undef LOCTEXT_NAMESPACE