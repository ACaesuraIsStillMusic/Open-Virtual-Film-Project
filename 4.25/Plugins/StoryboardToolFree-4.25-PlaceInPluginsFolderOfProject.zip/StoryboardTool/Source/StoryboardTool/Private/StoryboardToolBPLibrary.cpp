// Copyright Dan Corrigan 2020 All Rights Reserved.

#include "StoryboardToolBPLibrary.h"
#include "StoryboardTool.h"
#include "StoryboardToolSettings.h"
#include "Engine/TextureRenderTarget2D.h"

UStoryboardToolBPLibrary::UStoryboardToolBPLibrary(const FObjectInitializer& ObjectInitializer)
: Super(ObjectInitializer)
{

}

#if WITH_EDITOR
bool UStoryboardToolBPLibrary::VPStoryboardToolGetActorLockedState(AActor *actor) //Get locked state
{


	return actor->bLockLocation;
}


bool UStoryboardToolBPLibrary::VPStoryboardToolSetActorLockedState(AActor *actor, bool newState) //Set locked state
{
	actor->bLockLocation = newState;
	return actor->bLockLocation;
}


void UStoryboardToolBPLibrary::VPStoryboardToolSetRenderTargetMode(UTextureRenderTarget2D *renderTarget, TEnumAsByte < ETextureRenderTargetFormat > RenderFormat)
{
	renderTarget->RenderTargetFormat = RenderFormat;
	
	return;
}

void UStoryboardToolBPLibrary::VPStoryboardToolSetRenderTargetSize(UTextureRenderTarget2D *renderTarget, int sizeX, int sizeY)
{
	renderTarget->SizeX = sizeX;
	renderTarget->SizeY = sizeY;

	return;
}

FSoftObjectPath UStoryboardToolBPLibrary::VPStoryboardToolGetDefaultCameraClass() //get default camera class
{
	
	FSoftObjectPath camera = GetDefault<UStoryboardToolSettings>()->DefaultCamera;
	return camera;
	//return nullptr;
}




#endif
